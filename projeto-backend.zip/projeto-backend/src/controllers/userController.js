const asyncHandler = require('../middleware/asyncHandler');
const userService = require('../services/userService');
const authService = require('../services/authService');

exports.getById = asyncHandler(async (req, res) => {
  res.status(200).json(await userService.getById(req.params.id));
});

exports.create = asyncHandler(async (req, res) => {
  res.status(201).json(await userService.create(req.body));
});

exports.update = asyncHandler(async (req, res) => {
  await userService.update(req.params.id, req.body);
  res.status(204).send();
});

exports.remove = asyncHandler(async (req, res) => {
  await userService.remove(req.params.id);
  res.status(204).send();
});

exports.token = asyncHandler(async (req, res) => {
  res.status(200).json(await authService.generateToken(req.body));
});
